"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

44. Em uma eleição presidencial existem quatro candidatos. Os votos são informados por meio de código. Os
códigos utilizados são:
1 , 2, 3, 4 - Votos para os respectivos candidatos
(você deve montar a tabela ex: 1 - Jose/ 2- João/etc)
5 - Voto Nulo
6 - Voto em Branco
Faça um programa que calcule e mostre:
 O total de votos para cada candidato;
 O total de votos nulos;
 O total de votos em branco;14
 A percentagem de votos nulos sobre o total de votos;
 A percentagem de votos em branco sobre o total de votos. Para finalizar o conjunto de votos tem-se o valor
zero.

"""
votos1 = 0
votos2 = 0
votos3 = 0
votos4 = 0
votosnulos = 0
votosbrancos = 0
totalvotos = 0

print("Candidatos:")
print("1 - Jose")
print("2 - João")
print("3 - Maria")
print("4 - Ana")

while True:
    voto = int(input("Digite o código do voto (0 para terminar): "))
    if voto == 0:
        break
    if voto == 1:
        votos1 += 1
    elif voto == 2:
        votos2 += 1
    elif voto == 3:
        votos3 += 1
    elif voto == 4:
        votos4 += 1
    elif voto == 5:
        votosnulos += 1
    elif voto == 6:
        votosbrancos += 1
    else:
        print("Código inválido")
        continue
    totalvotos += 1

print("Votos de Jose:", votos1)
print("Votos de João:", votos2)
print("Votos de Maria:", votos3)
print("Votos de Ana:", votos4)
print("Votos nulos:", votosnulos)
print("Votos em branco:", votosbrancos)

if totalvotos > 0:
    print("Percentual de votos nulos: %.2f%%" % (votosnulos * 100 / totalvotos))
    print("Percentual de votos em branco: %.2f%%" % (votosbrancos * 100 / totalvotos))
else:
    print("Nenhum voto computado.")
