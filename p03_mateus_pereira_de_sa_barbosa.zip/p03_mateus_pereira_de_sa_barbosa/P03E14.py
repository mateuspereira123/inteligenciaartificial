"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

14. Faça um programa que peça 10 números inteiros, calcule e mostre a quantidade de números pares e a
quantidade de números impares.

"""
pares = 0
impares = 0

for i in range(10):
    num = int(input("Digite um número: "))
    if num % 2 == 0:
        pares = pares + 1
    else:
        impares = impares + 1

print("Pares:", pares)
print("Ímpares:", impares)
