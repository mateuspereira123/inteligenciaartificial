"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

45. Desenvolver um programa para verificar a nota do aluno em uma prova com 10 questões, o programa deve
perguntar ao aluno a resposta de cada questão e ao final comparar com o gabarito da prova e assim calcular
o total de acertos e a nota (atribuir 1 ponto por resposta certa). Após cada aluno utilizar o sistema deve ser
feita uma pergunta se outro aluno vai utilizar o sistema. Após todos os alunos terem respondido informar:
a. Maior e Menor Acerto;
b. Total de Alunos que utilizaram o sistema;
c. A Média das Notas da Turma.
Gabarito da Prova:
01 - A
02 - B
03 - C
04 - D
05 - E
06 - E
07 - D
08 - C
09 - B
10 - A
Após concluir isto você poderia incrementar o programa permitindo que o professor digite o gabarito da prova antes
dos alunos usarem o programa.

"""
gabarito = ["A","B","C","D","E","E","D","C","B","A"]
maior = 0
menor = 10
total = 0
soma = 0

while True:
    acertos = 0
    for i in range(10):
        r = input("Resposta da questão "+str(i+1)+": ").upper()
        if r == gabarito[i]:
            acertos = acertos + 1
    print("Acertos:", acertos)
    print("Nota:", acertos)
    
    if acertos > maior:
        maior = acertos
    if acertos < menor:
        menor = acertos
    total = total + 1
    soma = soma + acertos
    
    outro = input("Outro aluno? (s/n): ")
    if outro != "s":
        break

print("Maior acerto:", maior)
print("Menor acerto:", menor)
print("Total de alunos:", total)
print("Média da turma:", soma / total)
