"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

50. Sendo H= 1 + 1/2 + 1/3 + 1/4 + ... + 1/N, Faça um programa que calcule o valor de H com N termos.

"""
N = int(input("Digite N: "))
H = 0
for i in range(1, N+1):
    H += 1/i
print("H =", H)
