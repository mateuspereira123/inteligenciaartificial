"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

24. Faça um programa que calcule o mostre a média aritmética de N notas.

"""
N = int(input("Quantas notas você vai digitar? "))
soma = 0

for i in range(N):
    nota = float(input("Digite a nota: "))
    soma += nota

media = soma / N
print("Média:", media)
