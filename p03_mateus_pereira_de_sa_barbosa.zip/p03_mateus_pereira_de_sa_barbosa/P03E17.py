"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

17. Faça um programa que calcule o fatorial de um número inteiro fornecido pelo usuário. Ex.: 5!=5.4.3.2.1=120

"""
n = int(input("Digite um número inteiro: "))
fatorial = 1
while n > 1:
    fatorial = fatorial * n
    n = n - 1
print(fatorial)
