"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

5. Altere o programa anterior permitindo ao usuário informar as populações e as taxas de crescimento iniciais.
Valide a entrada e permita repetir a operação.

"""
"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

5. Altere o programa anterior permitindo ao usuário informar as populações e as taxas de crescimento iniciais.
Valide a entrada e permita repetir a operação.

"""
while True:
    a = int(input("População do país A: "))
    b = int(input("População do país B: "))
    taxaa = float(input("Taxa de crescimento de A (%): "))
    taxab = float(input("Taxa de crescimento de B (%): "))

    if a > 0 and b > 0 and taxaa > 0 and taxab > 0:
        anos = 0
        while a <= b:
            a = a * (1 + taxaa/100)
            b = b * (1 + taxab/100)
            anos = anos + 1
        print("Anos:", anos)
    else:
        print("Valores não são validos")

    repetir = input("Deseja repetir? (s/n): ")
    if repetir != 's':
        break
