"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

7. Faça um programa que leia 5 números e informe o maior número.

"""
maior = 0
for i in range(5):
    n = int(input("Digite um número: "))
    if i == 0 or n > maior:
        maior = n
print("Maior número:", maior)
