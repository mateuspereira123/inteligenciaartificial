"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

42. Faça um programa que leia uma quantidade indeterminada de números positivos e conte quantos deles
estão nos seguintes intervalos: [0-25], [26-50], [51-75] e [76-100]. A entrada de dados deverá terminar
quando for lido um número negativo.

"""
cont1 = 0
cont2 = 0
cont3 = 0
cont4 = 0

while True:
    n = int(input("Digite um número positivo (negativo para sair): "))
    if n < 0:
        break
    if n <= 25:
        cont1 = cont1 + 1
    elif n <= 50:
        cont2 = cont2 + 1
    elif n <= 75:
        cont3 = cont3 + 1
    elif n <= 100:
        cont4 = cont4 + 1

print("Números entre 0 e 25:", cont1)
print("Números entre 26 e 50:", cont2)
print("Números entre 51 e 75:", cont3)
print("Números entre 76 e 100:", cont4)
