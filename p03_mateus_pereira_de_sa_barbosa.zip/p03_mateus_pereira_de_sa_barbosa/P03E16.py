"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

16. A série de Fibonacci é formada pela seqüência 0,1,1,2,3,5,8,13,21,34,55,... Faça um programa que gere a
série até que o valor seja maior que 500.

"""
a = 0
b = 1

print(a)
print(b)

while True:
    c = a + b
    if c > 500:
        break
    print(c)
    a = b
    b = c
