"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

37. Uma academia deseja fazer um senso entre seus clientes para descobrir o mais alto, o mais baixo, a mais
gordo e o mais magro, para isto você deve fazer um programa que pergunte a cada um dos clientes da
academia seu código, sua altura e seu peso. O final da digitação de dados deve ser dada quando o usuário
digitar 0 (zero) no campo código. Ao encerrar o programa também deve ser informados os códigos e valores
do clente mais alto, do mais baixo, do mais gordo e do mais magro, além da média das alturas e dos pesos
dos clientes

"""
codigo = 1
maisalto = 0
codigoalto = 0
maisbaixo = 9999
codigobaixo = 0
maisgordo = 0
codigogordo = 0
maismagro = 9999
codigomagro = 0
somaaltura = 0
somapeso = 0
cont = 0

while True:
    codigo = int(input("Código do cliente (0 para sair): "))
    if codigo == 0:
        break
    altura = float(input("Altura: "))
    peso = float(input("Peso: "))
    cont += 1
    somaaltura += altura
    somapeso += peso

    if altura > maisalto:
        maisalto = altura
        codigoalto = codigo
    if altura < mais_baixo:
        maisbaixo = altura
        codigobaixo = codigo
    if peso > maisgordo:
        maisgordo = peso
        codigogordo = codigo
    if peso < maismagro:
        maismagro = peso
        codigomagro = codigo

if cont > 0:
    print("Mais alto:", codigoalto, "Altura:", maisalto)
    print("Mais baixo:", codigobaixo, "Altura:", maisbaixo)
    print("Mais gordo:", codigogordo, "Peso:", maisgordo)
    print("Mais magro:", codigomagro, "Peso:", maismagro)
    print("Média das alturas:", somaaltura / cont)
    print("Média dos pesos:", somapeso / cont)
else:
    print("Nenhum dado foi informado.")
