"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

26. Numa eleição existem três candidatos. Faça um programa que peça o número total de eleitores. Peça para
cada eleitor votar e ao final mostrar o número de votos de cada candidato.

"""

total = int(input("Número total de eleitores: "))
voto1 = 0
voto2 = 0
voto3 = 0

for i in range(total):
    voto = int(input("Vote no candidato (1, 2 ou 3): "))
    if voto == 1:
        voto1 += 1
    elif voto == 2:
        voto2 += 1
    elif voto == 3:
        voto3 += 1

print("Votos do candidato 1:", voto1)
print("Votos do candidato 2:", voto2)
print("Votos do candidato 3:", voto3)
