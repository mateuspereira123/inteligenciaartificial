"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

48. Faça um programa que peça um numero inteiro positivo e em seguida mostre este numero invertido.
o Exemplo:
12376489
98467321

"""
num = input("Digite um número inteiro positivo: ")
print(num[::-1])
