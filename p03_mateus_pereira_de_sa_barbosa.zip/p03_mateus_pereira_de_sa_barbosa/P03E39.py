"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

39. Faça um programa que leia dez conjuntos de dois valores, o primeiro representando o número do aluno e
o segundo representando a sua altura em centímetros. Encontre o aluno mais alto e o mais baixo. Mostre
o número do aluno mais alto e o número do aluno mais baixo, junto com suas alturas.

"""
maisaltonum = 0
maisaltoalt = 0
maisbaixonum = 0
maisbaixoalt = 10000

for i in range(10):
    num = int(input("Número do aluno: "))
    alt = int(input("Altura do aluno (cm): "))
    if alt > maisaltoalt:
        maisaltoalt = alt
        maisaltonum = num
    if alt < maisbaixoalt:
        maisbaixoalt = alt
        maisbaixonum = num

print("Aluno mais alto:", maisaltonum, "Altura:", maisaltoalt)
print("Aluno mais baixo:", maisbaixonum, "Altura:", maisbaixoalt)
