"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

15. A série de Fibonacci é formada pela seqüência 1,1,2,3,5,8,13,21,34,55,... Faça um programa capaz de
gerar a série até o n−ésimo termo.

"""
n = int(input("Digite o número de termos: "))

a = 1
b = 1

if n >= 1:
    print(a)
if n >= 2:
    print(b)

for i in range(3, n + 1):
    c = a + b
    print(c)
    a = b
    b = c
