"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

41. Faça um programa que receba o valor de uma dívida e mostre uma tabela com os seguintes dados: valor
da dívida, valor dos juros, quantidade de parcelas e valor da parcela.
o Os juros e a quantidade de parcelas seguem a tabela abaixo:
Quantidade de Parcelas % de Juros sobre o valor inicial da dívida
1 0
3 10
6 15
9 20
12 25
Exemplo de saída do programa:
Valor da Dívida Valor dos Juros Quantidade de Parcelas Valor da Parcela
R$ 1.000,00 0 1 R$ 1.000,00
R$ 1.100,00 100 3 R$ 366,00
R$ 1.150,00 150 6 R$ 191,67

"""
divida = float(input("Digite o valor da dívida: "))

parcelas = [1, 3, 6, 9, 12]
juros = [0, 10, 15, 20, 25]

print("Valor da Dívida  Juros  Parcelas  Valor da Parcela")

for i in range(len(parcelas)):
    juros_valor = divida * juros[i] / 100
    total = divida + juros_valor
    parcela = total / parcelas[i]
    print(f"R$ {total:.2f}        {juros_valor:.0f}      {parcelas[i]}       R$ {parcela:.2f}")
