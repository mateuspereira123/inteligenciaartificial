"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

21. Faça um programa que peça um número inteiro e determine se ele é ou não um número primo. Um número
primo é aquele que é divisível somente por ele mesmo e por 1.

"""
n = int(input("Digite um número inteiro: "))
if n < 2:
    print(n, "não é primo")
else:
    primo = True
    for i in range(2, n):
        if n % i == 0:
            primo = False
            break
    if primo:
        print(n, "é primo")
    else:
        print(n, "não é primo")
