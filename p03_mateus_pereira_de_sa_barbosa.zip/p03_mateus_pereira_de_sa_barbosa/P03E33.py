"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

33. O Departamento Estadual de Meteorologia lhe contratou para desenvolver um programa que leia as um
conjunto indeterminado de temperaturas, e informe ao final a menor e a maior temperaturas informadas,
bem como a média das temperaturas.

"""
temp = []
while True:
    t = input("Digite uma temperatura (ou 'sair' para terminar): ")
    if t.lower() == "sair":
        break
    temp.append(float(t))
if temp:
    print("Menor temperatura:", min(temp))
    print("Maior temperatura:", max(temp))
    print("Média das temperaturas:", sum(temp)/len(temp))
else:
    print("Nenhuma temperatura informada.")
