"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

3. Faça um programa que leia e valide as seguintes informações:
a. Nome: maior que 3 caracteres;
b. Idade: entre 0 e 150;
c. Salário: maior que zero;
d. Sexo: 'f' ou 'm';
e. Estado Civil: 's', 'c', 'v', 'd';

"""
while True:
    nome = input("Nome: ")
    if len(nome) > 3:
        break

while True:
    idade = int(input("Idade: "))
    if 0 <= idade <= 150:
        break

while True:
    salario = float(input("Salário: "))
    if salario > 0:
        break

while True:
    sexo = input("Sexo (f/m): ")
    if sexo == "f" or sexo == "m":
        break

while True:
    estado = input("Estado civil (s/c/v/d): ")
    if estado in ["s", "c", "v", "d"]:
        break

print("Tudo certo!")
