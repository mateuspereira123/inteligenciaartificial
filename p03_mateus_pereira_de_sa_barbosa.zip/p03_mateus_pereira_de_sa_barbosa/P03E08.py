"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

8. Faça um programa que leia 5 números e informe a soma e a média dos números.

"""
soma = 0
for i in range(5):
    n = float(input("Digite um número: "))
    soma += n
media = soma / 5
print("Soma:", soma)
print("Média:", media)
