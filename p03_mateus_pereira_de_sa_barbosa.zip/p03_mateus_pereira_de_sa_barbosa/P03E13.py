"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

13. Faça um programa que peça dois números, base e expoente, calcule e mostre o primeiro número elevado
ao segundo número. Não utilize a função de potência da linguagem.

"""
base = int(input("Digite a base: "))
expoente = int(input("Digite o expoente: "))

resultado = 1
for i in range(expoente):
    resultado = resultado * base

print("Resultado:", resultado)
