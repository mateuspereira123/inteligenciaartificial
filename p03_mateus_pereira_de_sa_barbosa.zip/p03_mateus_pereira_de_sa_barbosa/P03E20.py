"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

20. Altere o programa de cálculo do fatorial, permitindo ao usuário calcular o fatorial várias vezes e limitando o
fatorial a números inteiros positivos e menores que 16.

"""
while True:
    n = int(input("Digite um número inteiro positivo menor que 16 para calcular o fatorial: "))
    if n < 0 or n >= 16:
        print("Número inválido!")
        continue
    fatorial = 1
    for i in range(1, n+1):
        fatorial = fatorial * i
    print("Fatorial de", n, "é", fatorial)
    resp = input("Quer calcular outro fatorial? (s/n) ")
    if resp.lower() != 's':
        break
