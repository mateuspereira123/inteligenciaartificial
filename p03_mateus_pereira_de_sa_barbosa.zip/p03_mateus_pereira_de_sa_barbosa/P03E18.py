"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

18. Faça um programa que, dado um conjunto de N números, determine o menor valor, o maior valor e a soma
dos valores.

"""
N = int(input("Quantos números? "))
menor = None
maior = None
soma = 0
for i in range(N):
    num = float(input("Digite um número: "))
    if menor is None or num < menor:
        menor = num
    if maior is None or num > maior:
        maior = num
    soma = soma + num
print("Menor:", menor)
print("Maior:", maior)
print("Soma:", soma)
