"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

28. Faça um programa que calcule o valor total investido por um colecionador em sua coleção de CDs e o valor
médio gasto em cada um deles. O usuário deverá informar a quantidade de CDs e o valor para em cada
um.

"""
cds = int(input("Quantidade de CDs: "))
total = 0

for i in range(cds):
    valor = float(input("Valor do CD {}: ".format(i+1)))
    total += valor

media = total / cds
print("Valor total investido: R$", total)
print("Valor médio por CD: R$", media)
