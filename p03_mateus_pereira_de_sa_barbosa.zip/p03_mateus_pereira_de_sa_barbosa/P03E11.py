"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

11. Altere o programa anterior para mostrar no final a soma dos números.

"""
a = int(input("Digite o primeiro número: "))
b = int(input("Digite o segundo número: "))

soma = 0

if a < b:
    for i in range(a + 1, b):
        print(i)
        soma += i
else:
    for i in range(b + 1, a):
        print(i)
        soma += i

print("Soma dos números:", soma)
