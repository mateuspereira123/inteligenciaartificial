"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

34. Os números primos possuem várias aplicações dentro da Computação, por exemplo na Criptografia. Um
número primo é aquele que é divisível apenas por um e por ele mesmo. Faça um programa que peça um
número inteiro e determine se ele é ou não um número primo.

"""
num = int(input("Digite um número inteiro: "))
if num < 2:
    print("Não é primo")
else:
    primo = True
    for i in range(2, num):
        if num % i == 0:
            primo = False
            break
    if primo:
        print("É primo")
    else:
        print("Não é primo")
