"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

27. Faça um programa que calcule o número médio de alunos por turma. Para isto, peça a quantidade de
turmas e a quantidade de alunos para cada turma. As turmas não podem ter mais de 40 alunos.

"""

turmas = int(input("Quantidade de turmas: "))
totalalunos = 0

for i in range(turmas):
    alunos = int(input("Alunos na turma {}: ".format(i+1)))
    while alunos > 40:
        alunos = int(input("Máximo 40 alunos. Alunos na turma {}: ".format(i+1)))
    totalalunos += alunos

media = totalalunos / turmas
print("Média de alunos por turma:", media)
