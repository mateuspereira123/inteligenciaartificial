"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

19. Altere o programa anterior para que ele aceite apenas números entre 0 e 1000.

"""
N = int(input("Quantos números? "))
menor = None
maior = None
soma = 0
for i in range(N):
    num = float(input("Digite um número entre 0 e 1000: "))
    while num < 0 or num > 1000:
        num = float(input("Número inválido! Digite um número entre 0 e 1000: "))
    if menor is None or num < menor:
        menor = num
    if maior is None or num > maior:
        maior = num
    soma = soma + num
print("Menor:", menor)
print("Maior:", maior)
print("Soma:", soma)
