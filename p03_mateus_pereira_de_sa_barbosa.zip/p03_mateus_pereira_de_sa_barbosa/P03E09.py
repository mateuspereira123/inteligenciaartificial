"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

9. Faça um programa que imprima na tela apenas os números ímpares entre 1 e 50.

"""
for i in range(1, 51):
    if i % 2 != 0:
        print(i)
