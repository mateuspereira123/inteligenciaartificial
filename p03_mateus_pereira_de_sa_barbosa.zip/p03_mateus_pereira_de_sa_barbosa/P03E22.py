"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

22. Altere o programa de cálculo dos números primos, informando, caso o número não seja primo, por quais
número ele é divisível.

"""
n = int(input("Digite um número inteiro: "))
if n < 2:
    print(n, "não é primo")
else:
    divisores = []
    for i in range(2, n):
        if n % i == 0:
            divisores.append(i)
    if len(divisores) == 0:
        print(n, "é primo")
    else:
        print(n, "não é primo")
        print("É divisível por:", divisores)
