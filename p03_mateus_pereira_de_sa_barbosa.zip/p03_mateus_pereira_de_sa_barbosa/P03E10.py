"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 3 – Estruturas de repetição

10. Faça um programa que receba dois números inteiros e gere os números inteiros que estão no intervalo
compreendido por eles.

"""
a = int(input("Digite o primeiro número: "))
b = int(input("Digite o segundo número: "))

if a < b:
    for i in range(a + 1, b):
        print(i)
else:
    for i in range(b + 1, a):
        print(i)
