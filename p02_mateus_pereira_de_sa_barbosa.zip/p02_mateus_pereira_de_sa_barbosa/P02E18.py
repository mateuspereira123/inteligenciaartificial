"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
18. Faça um Programa que peça um número correspondente a um determinado ano e em seguida informe se
este ano é ou não bissexto

"""
ano = int(input("Digite um ano: "))

if (ano % 4 == 0 and ano % 100 != 0) or (ano % 400 == 0):
    print("Ano bissexto")
else:
    print("Não é ano bissexto")
