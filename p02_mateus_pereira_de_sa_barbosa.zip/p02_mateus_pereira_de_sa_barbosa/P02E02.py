"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

2. Faça um Programa que peça dois números e imprima o maior deles.
"""

n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))

if n1 > n2:
    print("O maior número é:", n1)
else:
    print("O maior número é:", n2)

