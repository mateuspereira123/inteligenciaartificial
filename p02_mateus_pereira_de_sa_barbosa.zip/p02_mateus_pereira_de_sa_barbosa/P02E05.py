"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
5. Faça um Programa que verifique se uma letra digitada é vogal ou consoante.
"""

letra = input("Digite uma letra: ")

if letra.lower() in ["a", "e", "i", "o", "u"]:
    print("Vogal")
else:
    print("Consoante")
