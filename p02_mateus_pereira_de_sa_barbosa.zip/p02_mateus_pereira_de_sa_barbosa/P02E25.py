"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
25. Faça um Programa que leia 2 números e em seguida pergunte ao usuário qual operação ele deseja realizar.
O resultado da operação deve ser acompanhado de uma frase que diga se o número é:
a. par ou ímpar;
b. positivo ou negativo;
c. inteiro ou decimal.

"""
n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))

print("Escolha a operação: +  -  *  /")
op = input("Operação: ")

if op == "+":
    resultado = n1 + n2
elif op == "-":
    resultado = n1 - n2
elif op == "*":
    resultado = n1 * n2
elif op == "/":
    if n2 != 0:
        resultado = n1 / n2
    else:
        print("Divisão por zero não é permitida")
        exit()
else:
    print("Operação inválida")
    exit()

print("Resultado:", resultado)

if resultado % 2 == 0:
    print("É par")
else:
    print("É impar")

if resultado > 0:
    print("É positivo")
elif resultado < 0:
    print("Negativo")
else:
    print("É zero")

if resultado == int(resultado):
    print("É inteiro")
else:
    print("É decimal")
