
"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
26. Faça um programa que faça 5 perguntas para uma pessoa sobre um crime. As perguntas são:
a. "Telefonou para a vítima?"
b. "Esteve no local do crime?"
c. "Mora perto da vítima?"
d. "Devia para a vítima?"
e. "Já trabalhou com a vítima?" O programa deve no final emitir uma classificação sobre a participação
da pessoa no crime. Se a pessoa responder positivamente a 2 questões ela deve ser classificada
como "Suspeita", entre 3 e 4 como "Cúmplice" e 5 como "Assassino". Caso contrário, ele será
classificado como "Inocente".
"""
resp = []

resp.append(input("Telefonou para a vítima? (s/n): "))
resp.append(input("Esteve no local do crime? (s/n): "))
resp.append(input("Mora perto da vítima? (s/n): "))
resp.append(input("Devia para a vítima? (s/n): "))
resp.append(input("Já trabalhou com a vítima? (s/n): "))

cont = 0

for r in resp:
    if r.lower() == "s":
        cont += 1

if cont == 2:
    print("Suspeita")
elif cont == 3 or cont == 4:
    print("Cúmplice")
elif cont == 5:
    print("Assassino")
else:
    print("Inocente")
