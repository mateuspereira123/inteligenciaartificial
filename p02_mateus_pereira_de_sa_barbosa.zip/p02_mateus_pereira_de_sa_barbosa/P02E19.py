"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
19. Faça um Programa que peça uma data no formato dd/mm/aaaa e determine se a mesma é uma data válida.

"""
data = input("Digite uma data (dd/mm/aaaa): ")

dia, mes, ano = map(int, data.split("/"))

valido = True

if mes < 1 or mes > 12:
    valido = False
elif dia < 1:
    valido = False
elif mes == 2:
    if (ano % 4 == 0 and ano % 100 != 0) or (ano % 400 == 0):
        if dia > 29:
            valido = False
    else:
        if dia > 28:
            valido = False
elif mes in [4, 6, 9, 11]:
    if dia > 30:
        valido = False
else:
    if dia > 31:
        valido = False

if valido:
    print("Data válida")
else:
    print("Data inválida")
