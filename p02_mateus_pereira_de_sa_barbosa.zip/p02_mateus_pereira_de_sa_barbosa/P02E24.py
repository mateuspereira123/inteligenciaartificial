"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
24. Faça um Programa que peça um número e informe se o número é inteiro ou decimal. Dica: utilize uma
função de arredondamento.

"""
num = float(input("Digite um número: "))

if num == int(num):
    print("É inteiro")
else:
    print("É decimal")