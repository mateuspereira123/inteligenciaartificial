"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
23. Faça um Programa que peça um número inteiro e determine se ele é par ou impar. Dica: utilize o operador
módulo (resto da divisão).

"""
num = int(input("Digite um número inteiro: "))

if num % 2 == 0:
    print("O número é Par")
else:
    print("O número é Ímpar")