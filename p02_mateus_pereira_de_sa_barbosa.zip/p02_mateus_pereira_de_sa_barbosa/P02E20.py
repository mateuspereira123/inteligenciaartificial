"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
20. Faça um Programa que leia um número inteiro menor que 1000 e imprima a quantidade de centenas,
dezenas e unidades do mesmo.
Observando os termos no plural a colocação do "e", da vírgula entre outros. Exemplo:
326 = 3 centenas, 2 dezenas e 6 unidades
12 = 1 dezena e 2 unidades Testar com: 326, 300, 100, 320, 310,305, 301, 101, 311, 111, 25, 20,
10, 21, 11, 1, 7 e 16

"""

num = int(input("Digite um número menor que 1000: "))

if num >= 1000 or num < 0:
    print("Numero não é valido")
else:
    c = num // 100
    d = (num % 100) // 10
    u = num % 10

    partes = []

    if c > 0:
        if c == 1:
            partes.append("1 centena")
        else:
            partes.append(f"{c} centenas")

    if d > 0:
        if d == 1:
            partes.append("1 dezena")
        else:
            partes.append(f"{d} dezenas")

    if u > 0:
        if u == 1:
            partes.append("1 unidade")
        else:
            partes.append(f"{u} unidades")

    if len(partes) == 3:
        print(f"{partes[0]}, {partes[1]} e {partes[2]}")
    elif len(partes) == 2:
        print(f"{partes[0]} e {partes[1]}")
    elif len(partes) == 1:
        print(partes[0])
    else:
        print("0 unidades")

