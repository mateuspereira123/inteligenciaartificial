"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

3. Faça um Programa que peça um valor e mostre na tela se o valor é positivo ou negativo
"""

v = float(input("Digite um valor: "))

if v >= 0:
    print("O valor é positivo.")
else:
    print("O valor é negativo.")
