"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 2
9. Faça um programa que pergunte o preço de três produtos e informe qual produto você deve comprar, sabendo que a decisão é sempre pelo mais barato.

"""
p1 = float(input("Digite o preço do primeiro produto: "))
p2 = float(input("Digite o preço do segundo produto: "))
p3 = float(input("Digite o preço do terceiro produto: "))

barato = p1

if p2 < barato:
    barato = p2
if p3 < barato:
    barato = p3

print("O produto mais barato e eh o que você deve comprar:", barato)