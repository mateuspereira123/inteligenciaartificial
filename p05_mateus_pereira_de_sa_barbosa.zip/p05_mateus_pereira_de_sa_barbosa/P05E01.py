"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

1. Faça um Programa que leia um vetor de 5 números inteiros e mostre-os.

"""
numeros = []

for i in range(5):
    numero = int(input("Digite um número inteiro: "))
    numeros.append(numero)

print("Os números digitados foram:")
for numero in numeros:
    print(numero)
