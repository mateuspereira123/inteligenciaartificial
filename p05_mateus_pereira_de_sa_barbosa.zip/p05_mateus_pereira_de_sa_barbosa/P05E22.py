"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

22. Sua organização acaba de contratar um estagiário para trabalhar no Suporte de Informática, com a
intenção de fazer um levantamento nas sucatas encontradas nesta área. A primeira tarefa dele é testar
todos os cerca de 200 mouses que se encontram lá, testando e anotando o estado de cada um deles,
para verificar o que se pode aproveitar deles.
Foi requisitado que você desenvolva um programa para registrar este levantamento. O programa
deverá receber um número indeterminado de entradas, cada uma contendo: um número de
identificação do mouse o tipo de defeito:
necessita da esfera;23
necessita de limpeza; a.necessita troca do cabo ou conector; a.quebrado ou inutilizado Uma
identificação igual a zero encerra o programa. Ao final o programa deverá emitir o seguinte
relatório:
Quantidade de mouses: 100
Situação Quantidade Percentual
1- necessita da esfera 40 40%
2- necessita de limpeza 30 30%
3- necessita troca do cabo ou conector 15 15%
4- quebrado ou inutilizado 15 15%


"""
totalmouses = 0
defeitos = [0, 0, 0, 0]

while True:
    idmouse = int(input("Número do mouse (0 para sair): "))
    if idmouse == 0:
        break
    print("Defeito:")
    print("1- necessita da esfera")
    print("2- necessita de limpeza")
    print("3- necessita troca do cabo ou conector")
    print("4- quebrado ou inutilizado")
    defeito = int(input("Digite o número do defeito: "))
    if defeito >= 1 and defeito <= 4:
        defeitos[defeito - 1] += 1
        totalmouses += 1

print(f"Quantidade de mouses: {totalmouses}")
print("Situação Quantidade Percentual")
print(f"1- necessita da esfera {defeitos[0]} {defeitos[0] * 100 // totalmouses}%")
print(f"2- necessita de limpeza {defeitos[1]} {defeitos[1] * 100 // totalmouses}%")
print(f"3- necessita troca do cabo ou conector {defeitos[2]} {defeitos[2] * 100 // totalmouses}%")
print(f"4- quebrado ou inutilizado {defeitos[3]} {defeitos[3] * 100 // totalmouses}%")


menor_consumo = consumos[0]
carro_economico = carros[0]

for i in range(5):
    litros = 1000 / consumos[i]
    custo = litros * 2.25
    print(f"{i+1} - {carros[i]} - {consumos[i]:.1f} - {litros:.1f} litros - R$ {custo:.2f}")
    if consumos[i] > menor_consumo:
        pass
    else:
        menor_consumo = consumos[i]
        carro_economico = carros[i]

print(f"O menor consumo é do {carro_economico}.")
