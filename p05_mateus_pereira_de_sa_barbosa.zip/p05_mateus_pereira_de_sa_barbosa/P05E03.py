"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

3. Faça um Programa que leia 4 notas, mostre as notas e a média na tela.

"""
notas = []

for i in range(4):
    nota = float(input("Digite a nota: "))
    notas.append(nota)

print("As notas digitadas foram:")
for nota in notas:
    print(nota)

media = sum(notas) / 4
print("A média é:", media)
