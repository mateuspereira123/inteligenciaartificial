"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

2. Faça um Programa que leia um vetor de 10 números reais e mostre-os na ordem inversa.

"""
numeros = []

for i in range(10):
    numero = float(input("Digite um número real: "))
    numeros.append(numero)

print("Números na ordem inversa:")
for i in range(9, -1, -1):
    print(numeros[i])
