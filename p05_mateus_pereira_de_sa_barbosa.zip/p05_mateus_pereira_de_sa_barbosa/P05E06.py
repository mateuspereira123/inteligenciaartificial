"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

6. Faça um Programa que peça as quatro notas de 10 alunos, calcule e armazene num vetor a média de
cada aluno, imprima o número de alunos com média maior ou igual a 7.0.

"""
medias = []
aprovados = 0

for i in range(10):
    soma = 0
    for j in range(4):
        nota = float(input("Digite a nota do aluno: "))
        soma += nota
    media = soma / 4
    medias.append(media)
    if media >= 7.0:
        aprovados += 1

print("Médias dos alunos:", medias)
print("Número de alunos com média maior ou igual a 7.0:", aprovados)
