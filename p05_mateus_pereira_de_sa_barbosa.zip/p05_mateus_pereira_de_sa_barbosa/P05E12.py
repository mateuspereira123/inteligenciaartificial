"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

12. Foram anotadas as idades e alturas de 30 alunos. Faça um Programa que determine quantos alunos com
mais de 13 anos possuem altura inferior à média de altura desses alunos.

"""
idades = []
alturas = []

for i in range(30):
    idade = int(input("Digite a idade do aluno: "))
    altura = float(input("Digite a altura do aluno: "))
    idades.append(idade)
    alturas.append(altura)

media_altura = sum(alturas) / 30

contador = 0
for i in range(30):
    if idades[i] > 13 and alturas[i] < media_altura:
        contador += 1

print("Número de alunos com mais de 13 anos e altura abaixo da média:", contador)
