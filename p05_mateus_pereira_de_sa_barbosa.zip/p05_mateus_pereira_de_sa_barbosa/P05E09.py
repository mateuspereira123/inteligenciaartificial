"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

9. Faça um Programa que leia um vetor A com 10 números inteiros, calcule e mostre a soma dos quadrados
dos elementos do vetor.

"""
A = []

for i in range(10):
    numero = int(input("Digite um número inteiro: "))
    A.append(numero)

soma_quadrados = 0
for numero in A:
    somaquadrados += numero ** 2

print("Soma dos quadrados dos elementos:", somaquadrados)
