"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

14. Utilizando listas faça um programa que faça 5 perguntas para uma pessoa sobre um crime. As perguntas
são:
a. "Telefonou para a vítima?"
b. "Esteve no local do crime?"
c. "Mora perto da vítima?"
d. "Devia para a vítima?"
e. "Já trabalhou com a vítima?" O programa deve no final emitir uma classificação sobre a
participação da pessoa no crime. Se a pessoa responder positivamente a 2 questões ela deve
ser classificada como "Suspeita", entre 3 e 4 como "Cúmplice" e 5 como "Assassino". Caso
contrário, ele será classificado como "Inocente".

"""
perguntas = [
    "Telefonou para a vítima? (sim/não) ",
    "Esteve no local do crime? (sim/não) ",
    "Mora perto da vítima? (sim/não) ",
    "Devia para a vítima? (sim/não) ",
    "Já trabalhou com a vítima? (sim/não) "
]

respostas_sim = 0

for pergunta in perguntas:
    resposta = input(pergunta).lower()
    if resposta == "sim":
        respostas_sim += 1

if respostas_sim == 2:
    print("Suspeita")
elif 3 <= respostas_sim <= 4:
    print("Cúmplice")
elif respostas_sim == 5:
    print("Assassino")
else:
    print("Inocente")
