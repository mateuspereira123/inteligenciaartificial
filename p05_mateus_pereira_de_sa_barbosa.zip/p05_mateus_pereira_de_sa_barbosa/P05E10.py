"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

10. Faça um Programa que leia dois vetores com 10 elementos cada. Gere um terceiro vetor de 20 elementos,
cujos valores deverão ser compostos pelos elementos intercalados dos dois outros vetores.

"""
vetor1 = []
vetor2 = []
vetor3 = []

for i in range(10):
    numero = int(input("Digite um número para o primeiro vetor: "))
    vetor1.append(numero)

for i in range(10):
    numero = int(input("Digite um número para o segundo vetor: "))
    vetor2.append(numero)

for i in range(10):
    vetor3.append(vetor1[i])
    vetor3.append(vetor2[i])

print("Vetor intercalado:", vetor3)
