"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

7. Faça um Programa que leia um vetor de 5 números inteiros, mostre a soma, a multiplicação e os números.

"""
numeros = []

for i in range(5):
    numero = int(input("Digite um número inteiro: "))
    numeros.append(numero)

soma = sum(numeros)

multiplicacao = 1
for numero in numeros:
    multiplicacao *= numero

print("Números digitados:", numeros)
print("Soma:", soma)
print("Multiplicação:", multiplicacao)
