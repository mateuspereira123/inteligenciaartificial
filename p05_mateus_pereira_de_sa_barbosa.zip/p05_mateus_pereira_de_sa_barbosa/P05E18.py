"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

18. Uma grande emissora de televisão quer fazer uma enquete entre os seus telespectadores para saber
qual o melhor jogador após cada jogo. Para isto, faz-se necessário o desenvolvimento de um programa,
que será utilizado pelas telefonistas, para a computação dos votos. Sua equipe foi contratada para
desenvolver este programa, utilizando a linguagem de programação C++. Para computar cada voto, a
telefonista digitará um número, entre 1 e 23, correspondente ao número da camisa do jogador. Um
número de jogador igual zero, indica que a votação foi encerrada. Se um número inválido for digitado, o
programa deve ignorá-lo, mostrando uma breve mensagem de aviso, e voltando a pedir outro número.
Após o final da votação, o programa deverá exibir:
a. O total de votos computados;
b. Os númeos e respectivos votos de todos os jogadores que receberam votos;
c. O percentual de votos de cada um destes jogadores;
d. O número do jogador escolhido como o melhor jogador da partida, juntamente com o número de
votos e o percentual de votos dados a ele.
§ Observe que os votos inválidos e o zero final não devem ser computados como votos.
O resultado aparece ordenado pelo número do jogador. O programa deve fazer uso de
arrays. O programa deverá executar o cálculo do percentual de cada jogador através
de uma função. Esta função receberá dois parâmetros: o número de votos de um
jogador e o total de votos. A função calculará o percentual e retornará o valor
calculado. Abaixo segue uma tela de exemplo. O disposição das informações deve ser
o mais próxima possível ao exemplo. Os dados são fictícios e podem mudar a cada
execução do programa. Ao final, o programa deve ainda gravar os dados referentes ao
resultado da votação em um arquivo texto no disco, obedecendo a mesma disposição
apresentada na tela.
Enquete: Quem foi o melhor jogador?
Número do jogador (0=fim): 9
Número do jogador (0=fim): 10
Número do jogador (0=fim): 9
Número do jogador (0=fim): 10
Número do jogador (0=fim): 11
Número do jogador (0=fim): 10
Número do jogador (0=fim): 50
Informe um valor entre 1 e 23 ou 0 para sair!
Número do jogador (0=fim): 9
Número do jogador (0=fim): 9
Número do jogador (0=fim): 0
Resultado da votação:
Foram computados 8 votos.
Jogador Votos %
9 4 50,0%
10 3 37,5%
11 1 12,5%21
O melhor jogador foi o número 9, com 4 votos, correspondendo a 50%
do total de votos.

"""
def calcular_percentual(votos, total):
    return (votos / total) * 100 if total > 0 else 0

votos = [0] * 23
totalvotos = 0

while True:
    jogador = int(input("Número do jogador (0=fim): "))
    if jogador == 0:
        break
    if 1 <= jogador <= 23:
        votos[jogador - 1] += 1
        totalvotos += 1
    else:
        print("Informe um valor entre 1 e 23 ou 0 para sair!")

print("Resultado da votação:")
print(f"Foram computados {totalvotos} votos.")
print("Jogador Votos %")

melhorjogador = 0
maisvotos = 0

for i in range(23):
    if votos[i] > 0:
        percentual = calcular_percentual(votos[i], totalvotos)
        print(f"{i+1} {votos[i]} {percentual:.1f}%")
        if votos[i] > maisvotos:
            maisvotos = votos[i]
            melhorjogador = i + 1

if melhorjogador != 0:
    percentualmelhor = calcular_percentual(maisvotos, totalvotos)
    print(f"O melhor jogador foi o número {melhorjogador}, com {maisvotos} votos, correspondendo a {percentualmelhor:.0f}% do total de votos.")

with open("resultado_votacao.txt", "w") as arquivo:
    arquivo.write("Resultado da votação:\n")
    arquivo.write(f"Foram computados {totalvotos} votos.\n")
    arquivo.write("Jogador Votos %\n")
    for i in range(23):
        if votos[i] > 0:
            percentual = calcular_percentual(votos[i], totalvotos)
            arquivo.write(f"{i+1} {votos[i]} {percentual:.1f}%\n")
    if melhorjogador != 0:
        arquivo.write(f"O melhor jogador foi o número {melhorjogador}, com {maisvotos} votos, correspondendo a {percentualmelhor:.0f}% do total de votos.\n")
