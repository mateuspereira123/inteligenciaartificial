"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

11. Altere o programa anterior, intercalando 3 vetores de 10 elementos cada.

"""
vet1 = []
vet2 = []
vet3 = []

for i in range(10):
    numero = int(input("Digite um número para o primeiro vetor: "))
    vet1.append(numero)

for i in range(10):
    numero = int(input("Digite um número para o segundo vetor: "))
    vet2.append(numero)

for i in range(10):
    vet3.append(vet1[i])
    vet3.append(vet2[i])

print("Vetor intercalado:", vet3)
