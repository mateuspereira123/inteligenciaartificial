"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

24. Faça um programa que simule um lançamento de dados. Lance o dado 100 vezes e armazene os
resultados em um vetor . Depois, mostre quantas vezes cada valor foi conseguido. Dica: use um vetor de
contadores(1-6) e uma função para gerar numeros aleatórios, simulando os lançamentos dos dados.

"""
import random

def lancarDado():
    return random.randint(1, 6)

resultados = [0, 0, 0, 0, 0, 0]

for _ in range(100):
    resultado = lancarDado()
    resultados[resultado - 1] += 1

for i in range(6):
    print(f"Valor {i+1} saiu {resultados[i]} vezes")
