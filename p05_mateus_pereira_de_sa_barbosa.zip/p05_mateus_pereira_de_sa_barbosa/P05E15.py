"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 5 – Listas

15. Faça um programa que leia um número indeterminado de valores, correspondentes a notas, encerrando
a entrada de dados quando for informado um valor igual a -1 (que não deve ser armazenado). Após esta
entrada de dados, faça:
a. Mostre a quantidade de valores que foram lidos;
b. Exiba todos os valores na ordem em que foram informados, um ao lado do outro;
c. Exiba todos os valores na ordem inversa à que foram informados, um abaixo do outro;
d. Calcule e mostre a soma dos valores;
e. Calcule e mostre a média dos valores;
f. Calcule e mostre a quantidade de valores acima da média calculada;
g. Calcule e mostre a quantidade de valores abaixo de sete;
h. Encerre o programa com uma mensagem;

"""
notas = []

while True:
    nota = float(input("Digite uma nota (-1 para encerrar): "))
    if nota == -1:
        break
    notas.append(nota)

print("Quantidade de valores lidos:", len(notas))

print("Valores na ordem informada:", end=" ")
for nota in notas:
    print(nota, end=" ")
print()

print("Valores na ordem inversa:")
for i in range(len(notas)-1, -1, -1):
    print(notas[i])

soma = sum(notas)
print("Soma dos valores:", soma)

media = soma / len(notas) if len(notas) > 0 else 0
print("Média dos valores:", media)

acima_media = 0
abaixo_sete = 0
for nota in notas:
    if nota > media:
        acima_media += 1
    if nota < 7:
        abaixo_sete += 1

print("Quantidade de valores acima da média:", acima_media)
print("Quantidade de valores abaixo de sete:", abaixo_sete)

print("Programa encerrado.")
