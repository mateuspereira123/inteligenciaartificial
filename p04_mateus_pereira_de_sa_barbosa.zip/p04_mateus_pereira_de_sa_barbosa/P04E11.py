"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

11. Jogo de Forca. Desenvolva um jogo da forca. O programa terá uma lista de palavras lidas de um arquivo
texto e escolherá uma aleatoriamente. O jogador poderá errar 6 vezes antes de ser enforcado.
 Digite uma letra: A
 -> Você errou pela 1ª vez. Tente de novo!
 o
Digite uma letra: O
 A palavra é: _ _ _ _ O
 o
Digite uma letra: E
 A palavra é: _ E _ _ O
 o
Digite uma letra: S
 -> Você errou pela 2ª vez. Tente de novo!

"""
import random

arquivo = open("palavras.txt", "r")
palavras = arquivo.read().splitlines()
arquivo.close()

palavra = random.choice(palavras).upper()
letras_descobertas = ["_"] * len(palavra)
erros = 0
tentadas = []

while erros < 6 and "_" in letras_descobertas:
    print("Palavra:", " ".join(letras_descobertas))
    letra = input("Digite uma letra: ").upper()

    if letra in tentadas:
        print("Você já tentou essa letra.")
        continue

    tentadas.append(letra)

    if letra in palavra:
        for i in range(len(palavra)):
            if palavra[i] == letra:
                letras_descobertas[i] = letra
    else:
        erros += 1
        print(f"-> Você errou pela {erros}ª vez. Tente de novo!")

if "_" not in letras_descobertas:
    print("Parabéns! Você acertou a palavra:", palavra)
else:
    print("Você foi enforcado. A palavra era:", palavra)


