""""""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

10. Número por extenso. Escreva um programa que solicite ao usuário a digitação de um número até 99 e
imprima-o na tela por extenso.

"""
unidades = ["zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
de10a19 = ["dez", "onze", "doze", "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"]
dezenas = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]

numero = int(input("Digite um número até 99: "))

if 0 <= numero < 10:
    print(unidades[numero])
elif 10 <= numero < 20:
    print(de10a19[numero - 10])
elif 20 <= numero < 100:
    dezena = numero // 10
    unidade = numero % 10
    if unidade == 0:
        print(dezenas[dezena])
    else:
        print(dezenas[dezena] + " e " + unidades[unidade])
else:
    print("Número fora do intervalo.")
