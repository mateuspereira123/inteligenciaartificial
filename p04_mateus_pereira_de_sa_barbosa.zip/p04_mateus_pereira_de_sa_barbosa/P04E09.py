"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

9. Verificação de CPF. Desenvolva um programa que solicite a digitação de um número de CPF no
formato xxx.xxx.xxx-xx e indique se é um número válido ou inválido através da validação dos dígitos
verificadores edos caracteres de formatação.

"""
cpf = input("Digite o CPF (xxx.xxx.xxx-xx): ")

if len(cpf) != 14 or cpf[3] != '.' or cpf[7] != '.' or cpf[11] != '-':
    print("Formato inválido.")
else:
    numeros = cpf.replace(".", "").replace("-", "")
    if not numeros.isdigit():
        print("Formato inválido.")
    else:
        soma1 = 0
        for i in range(9):
            soma1 += int(numeros[i]) * (10 - i)
        digito1 = (soma1 * 10) % 11
        if digito1 == 10:
            digito1 = 0

        soma2 = 0
        for i in range(10):
            soma2 += int(numeros[i]) * (11 - i)
        digito2 = (soma2 * 10) % 11
        if digito2 == 10:
            digito2 = 0

        if digito1 == int(numeros[9]) and digito2 == int(numeros[10]):
            print("CPF válido.")
        else:
            print("CPF inválido.")
