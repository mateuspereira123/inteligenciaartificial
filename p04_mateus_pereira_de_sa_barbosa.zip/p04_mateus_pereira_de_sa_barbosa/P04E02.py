"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

2. Nome ao contrário em maiúsculas. Faça um programa que permita ao usuário digitar o seu nome e em
seguida mostre o nome do usuário de trás para frente utilizando somente letras maiúsculas. Dica:
lembre−se que ao informar o nome o usuário pode digitar letras maiúsculas ou minúsculas.

"""
nome = input("Digite seu nome: ")
nomeinvertido = nome[::-1].upper()
print("Nome invertido em maiúsculas:", nomeinvertido)
