"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

7. Conta espaços e vogais. Dado uma string com uma frase informada pelo usuário (incluindo espaços em
branco), conte:
a. quantos espaços em branco existem na frase.
b. quantas vezes aparecem as vogais a, e, i, o, u.

"""
frase = input("Digite uma frase: ")

espacos = frase.count(' ')
a = frase.lower().count('a')
e = frase.lower().count('e')
i = frase.lower().count('i')
o = frase.lower().count('o')
u = frase.lower().count('u')

print("Espaços em branco:", espacos)
print("Quantidade de 'a':", a)
print("Quantidade de 'e':", e)
print("Quantidade de 'i':", i)
print("Quantidade de 'o':", o)
print("Quantidade de 'u':", u)
