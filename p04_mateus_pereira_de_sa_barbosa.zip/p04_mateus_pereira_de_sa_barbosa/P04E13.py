"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

13. Jogo da palavra embaralhada. Desenvolva um jogo em que o usuário tenha que adivinhar uma palavra
que será mostrada com as letras embaralhadas. O programa terá uma lista de palavras lidas de um arquivo
texto e escolherá uma aleatoriamente. O jogador terá seis tentativas para adivinhar a palavra. Ao final a
palavra deve ser mostrada na tela, informando se o usuário ganhou ou perdeu o jogo.

"""
import random

arquivo = open("palavras.txt", "r")
palavras = arquivo.read().splitlines()
arquivo.close()

palavra = random.choice(palavras).upper()
embaralhada = list(palavra)
random.shuffle(embaralhada)
embaralhada = "".join(embaralhada)

print("Adivinhe a palavra:", embaralhada)

tentativas = 6

while tentativas > 0:
    tentativa = input("Digite sua tentativa: ").upper()
    if tentativa == palavra:
        print("Parabéns! Você acertou a palavra:", palavra)
        break
    else:
        tentativas -= 1
        print("Errado! Tentativas restantes:", tentativas)

if tentativa != palavra:
    print("Você perdeu. A palavra era:", palavra)

