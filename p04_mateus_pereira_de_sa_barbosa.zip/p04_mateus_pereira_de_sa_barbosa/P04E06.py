"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

6. Data por extenso. Faça um programa que solicite a data de nascimento (dd/mm/aaaa) do usuário e
imprima a data com o nome do mês por extenso.
 Data de Nascimento: 29/10/1973
 Você nasceu em 29 de Outubro de 1973.

"""
data = input("Digite sua data de nascimento (dd/mm/aaaa): ")
dia, mes, ano = data.split('/')

meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
         "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]

mes_extenso = meses[int(mes) - 1]

print(f"Você nasceu em {dia} de {mes_extenso} de {ano}.")
