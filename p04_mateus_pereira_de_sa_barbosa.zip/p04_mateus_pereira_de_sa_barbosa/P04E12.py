"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

12. Valida e corrige número de telefone. Faça um programa que leia um número de telefone, e corrija o
número no caso deste conter somente 7 dígitos, acrescentando o '3' na frente. O usuário pode informar o
número com ou sem o traço separador.
o Valida e corrige número de telefone
o Telefone: 461-0133
o Telefone possui 7 dígitos. Vou acrescentar o digito três na frente.
o Telefone corrigido sem formatação: 34610133
o Telefone corrigido com formatação: 3461-0133

"""
telefone = input("Telefone: ").replace("-", "")

if len(telefone) == 7:
    print("Telefone possui 7 dígitos. Vou acrescentar o digito três na frente.")
    telefone = "3" + telefone
    print("Telefone corrigido sem formatação:", telefone)
    print("Telefone corrigido com formatação:", telefone[:4] + "-" + telefone[4:])
else:
    print("Telefone está correto:", telefone[:4] + "-" + telefone[4:])

