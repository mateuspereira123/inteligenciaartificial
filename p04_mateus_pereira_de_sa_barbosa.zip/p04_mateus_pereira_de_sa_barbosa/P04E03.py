"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Parte 4 – Strings e arquivos 

3. Nome na vertical. Faça um programa que solicite o nome do usuário e imprima-o na vertical.
 F
 U
 L
 A
 N
 O

"""
nome = input("Digite seu nome: ")
for letra in nome:
    print(letra)
