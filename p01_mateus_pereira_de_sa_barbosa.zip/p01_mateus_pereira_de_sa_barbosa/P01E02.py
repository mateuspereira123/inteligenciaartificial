"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

2 - Faça um Programa que peça dois números e imprima a soma.
"""

num1 = float(input("Digite o primeiro numero: "))
num2 = float(input("Digite o segundo numero: "))
soma = num1 + num2
print("A soma dos numeros eh: ", soma)