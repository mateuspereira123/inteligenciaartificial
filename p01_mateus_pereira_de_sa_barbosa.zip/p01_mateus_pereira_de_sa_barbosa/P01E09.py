"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

9. Faça um Programa que peça a temperatura em graus Celsius, transforme e mostre em graus Fahrenheit.
"""

celsius = float(input("Digite a temperatura em graus Celsius: "))
fahrenheit = (celsius * 9 / 5) + 32
print("A temperatura em graus Fahrenheit é:", fahrenheit)
