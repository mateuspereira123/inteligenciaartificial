"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

1 - Faça um Programa que peça um número e então mostre a mensagem O número informado foi [número]
"""

num = float(input("Informe um numero: "))
print("O numero informado foi: ",num)