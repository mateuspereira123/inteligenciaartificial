
"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

6 - Faça um Programa que calcule a área de um quadrado, em seguida mostre o dobro desta área para o
usuário

"""
lado = float(input("Digite o valor do lado do quadrado: "))
area = lado * lado
dobro = area * 2

print("A área do quadrado é:", area)
print("O dobro da área é:", dobro)