"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

12. Tendo como dado de entrada a altura (h) de uma pessoa, construa um algoritmo que calcule seu peso ideal,
utilizando as seguintes fórmulas:
a. Para homens: (72.7*h) - 58
b. Para mulheres: (62.1*h) - 44.7
"""

altura = float(input("Digite sua altura em metros: "))
sexo = input("Digite seu sexo (masculino ou feminino): ")

if sexo == "masculino":
    peso = (72.7 * altura) - 58
elif sexo == "feminino":
    peso = (62.1 * altura) - 44.7
else:
    print("O sexo não foi digitado. Digite 'masculino' ou 'feminino'.")

if peso is not None:
    print("Seu peso ideal é:", peso, "kg")

