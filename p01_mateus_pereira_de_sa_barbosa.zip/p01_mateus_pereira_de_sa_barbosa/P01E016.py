"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

16. Faça um Programa para uma loja de tintas. O programa deverá pedir o tamanho em metros quadrados da
área a ser pintada. Considere que a cobertura da tinta é de 1 litro para cada 6 metros quadrados e que a
tinta é vendida em latas de 18 litros, que custam R$ 80,00 ou em galões de 3,6 litros, que custam R$ 25,00.
o Informe ao usuário as quantidades de tinta a serem compradas e os respectivos preços em 3
situações:
comprar apenas latas de 18 litros;
comprar apenas galões de 3,6 litros;
misturar latas e galões, de forma que o desperdício de tinta seja menor. Acrescente 10% de folga e
sempre arredonde os valores para cima, isto é, considere latas cheias.
"""

area = float(input("Digite o tamanho da área que vai ser pintada (em m^2): "))
area = area * 1.1
litros = area / 6
latas18 = int(litros / 18)

if litros % 18 != 0:
    latas18 += 1
    
precolatas = latas18 * 80
galoes36 = int(litros / 3.6)

if litros % 3.6 != 0:
    galoes36 += 1
precogaloes = galoes36 * 25

latasmistas = int(litros / 18)
resto = litros % 18
galoesmistos = int(resto / 3.6)
if resto % 3.6 != 0:
    galoesmistos += 1
precomisto = (latasmistas * 80) + (galoesmistos * 25)

print("\n Somente latas de 18L ")
print("Latas:", latas18)
print("Preço: R$ ", precolatas)

print("\n Apenas galões de 3.6L")
print("Galoes: ", galoes36)
print("Preço: R$ ", precogaloes)

print("\n Mistura de latas e galões ")
print("Latas:", latasmistas)
print("Galões:", galoesmistos)
print("Preço: R$ ", precomisto)
