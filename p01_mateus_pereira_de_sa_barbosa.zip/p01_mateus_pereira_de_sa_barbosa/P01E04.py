"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

Faça um Programa que converta metros para centímetros
"""
met = float(input("Digite o valor em metros para ser convertido: "))
cent = met*100
print("O resultado da conversão de metros em centimetros eh: ", cent,"centímetros")