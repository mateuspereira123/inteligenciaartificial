"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

10. Faça um Programa que peça 2 números inteiros e um número real. Calcule e mostre:
a. o produto do dobro do primeiro com metade do segundo .
b. a soma do triplo do primeiro com o terceiro.
c. o terceiro elevado ao cubo.
"""

num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))
num3 = float(input("Digite um número real: "))

result_a = (2 * num1) * (num2 / 2)
result_b = (3 * num1) + num3
result_c = num3 ** 3 

print("a. o produto do dobro do primeiro com metade do segundo eh:", result_a)
print("b. a soma do triplo do primeiro com o terceiro eh:", result_b)
print("c. o terceiro elevado ao cubo eh", result_c)
