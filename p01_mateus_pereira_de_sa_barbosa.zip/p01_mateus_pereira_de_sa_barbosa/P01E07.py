
"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

7. Faça um Programa que pergunte quanto você ganha por hora e o número de horas trabalhadas no mês.
Calcule e mostre o total do seu salário no referido mês.
"""
valorhora = float(input("Quanto você ganha por hora? "))
horastrabalhadas = float(input("Quantas horas você trabalhou no mês? "))
salario = valorhora * horastrabalhadas
print("O seu salário no mês é: R$", salario)
