"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

3 - Faça um Programa que peça as 4 notas bimestrais e mostre a média.
"""

nota1 = float(input("Digite a primeira nota: "))
nota2= float(input("Digite a segunda nota: "))
nota3 = float(input("Digite a terceira nota: "))
nota4 = float(input("Digite a quarta nota: "))
med = (nota1+nota2+nota3+nota4)/4
print("A média das notas eh: ", med)