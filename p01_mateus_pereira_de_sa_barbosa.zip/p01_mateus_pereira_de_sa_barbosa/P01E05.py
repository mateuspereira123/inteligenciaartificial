"""
Aluno: Mateus Pereira de Sá Barbosa
Turma:ENGCO212N01

5 - Faça um Programa que converta metros para centímetros.
"""

metros = float(input("Digite o valor em metros: "))

cent = metros * 100

print("O valor em centímetros eh: ", cent, "centímetros")
